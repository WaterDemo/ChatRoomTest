package main

import (
	"net/http"
	"log"
//	"github.com/gorilla/websocket"
//	"time"
	"fmt"
)
//const (
//	maxMessageSize = 1024
//	readWait = 60*time.Second
//	writeWait = 60*time.Second
//	pingPeriod = 54 *time.Second
//
//)
//var upgrader = websocket.Upgrader{
//	ReadBufferSize:1024,
//	WriteBufferSize:1024,
//
//}
//var message_chan chan []byte
//func read(conn *websocket.Conn){
//	defer func(){
//		conn.Close()
//	}()
//	conn.SetReadLimit(maxMessageSize)
//	conn.SetReadDeadline(time.Now().Add(readWait))
//	conn.SetPongHandler(func(string)error {conn.SetReadDeadline(time.Now().Add(readWait));return nil})
//	for{
//		_,message,err := conn.ReadMessage()
//		if err!=nil{
//			log.Fatal(err)
//			break
//		}
//		fmt.Println("read : "+string(message))
//		message_chan <- message
//	}
//
//
//}
//func write(conn *websocket.Conn)  {
//	ticker :=time.NewTicker(pingPeriod)
//	defer func() {
//		conn.Close()
//	}()
//	for{
//		select {
//		case message :=<-message_chan:
//			conn.SetWriteDeadline(time.Now().Add(writeWait))
//			w,err :=conn.NextWriter(websocket.TextMessage)
//			if err!=nil{
//				return
//			}
//			w.Write(message)
//		        fmt.Println("write : "+string(message))
//			if err=w.Close();err!=nil{
//				return
//			}
//		case <-ticker.C:
//			conn.SetWriteDeadline(time.Now().Add(writeWait))
//			if err := conn.WriteMessage(websocket.PingMessage,[]byte{});err!=nil{
//				return
//			}
//
//		}
//	}
//
//
//}
//func wsHander(w http.ResponseWriter,r *http.Request){
//
//	conn,err := upgrader.Upgrade(w,r,nil)
//
//	if err!=nil{
//		log.Fatal(err)
//		return
//	}
//	go read(conn)
//	write(conn)
//
//
//
//}

func main() {

 test()
}
func test(){
	//message_chan = make(chan []byte,1024)
	//http.Header{}
	fs:=http.FileServer(http.Dir("res"))
	http.Handle("/",fs)
	//http.HandleFunc("/ws",wsHander)
	hub :=NewHub()
	go hub.run()
	http.HandleFunc("/ws", func(w http.ResponseWriter,r *http.Request) {
		WsHander(hub,w,r)

	})
	err:=http.ListenAndServe(":8888",nil)
	if err != nil {
		log.Fatal(err)
	}
}
func  temp()  {
	var test map[*string]string
	test = make(map[*string]string)
	var i1 = "hello"
	var v1= "HELLO"
	test[&i1]=v1
	var i2 ="world"
	var v2 ="WORLD"
	test[&i2] = v2
	for i,v :=range test{
		fmt.Println("index: "+*i+" value:"+v)
	}
	arr :=make([]int,0)
	arr = append(arr,1)
	arr = append(arr,2)

	fmt.Println(arr)


	ch := make(chan int,1)
	ch <- 1
	ch <- 2
	fmt.Println(<-ch)

}
