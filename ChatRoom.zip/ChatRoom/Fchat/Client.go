package main

import (
	"github.com/gorilla/websocket"
	"time"
	"log"
	"fmt"
	"net/http"
)

type Client struct {
	conn *websocket.Conn
	message chan []byte
	hub *Hub
}
const (
	maxMessageSize = 1024
	readWait = 60*time.Second
	writeWait = 60*time.Second
	pingPeriod = 54 *time.Second

)
var upgrader = websocket.Upgrader{
	ReadBufferSize:1024,
	WriteBufferSize:1024,

}

func (client *Client)read(){
	defer func(){
		client.hub.unregister<-client
		client.conn.Close()
	}()
	client.conn.SetReadLimit(maxMessageSize)
	client.conn.SetReadDeadline(time.Now().Add(readWait))
	client.conn.SetPongHandler(func(string)error {client.conn.SetReadDeadline(time.Now().Add(readWait));return nil})
	for{
		_,message,err := client.conn.ReadMessage()
		if err!=nil{
			log.Fatal(err)
			break
		}
		fmt.Println("read : "+string(message))
		client.hub.broadcast <- message
	}


}
func (client *Client)write()  {
	ticker :=time.NewTicker(pingPeriod)
	defer func() {
		ticker.Stop()
		client.hub.unregister<-client
		client.conn.Close()
	}()
	for{
		select {
		case message :=<-client.message:
			client.conn.SetWriteDeadline(time.Now().Add(writeWait))
			w,err :=client.conn.NextWriter(websocket.TextMessage)
			if err!=nil{
				return
			}
			w.Write(message)
			fmt.Println("write : "+string(message))
		        len := len(client.message)
		        for i:=0;i<len;i++{
				w.Write(message)
				fmt.Println("write : "+string(message))
			}
			if err=w.Close();err!=nil{
				return
			}
		case <-ticker.C:
			client.conn.SetWriteDeadline(time.Now().Add(writeWait))
			if err := client.conn.WriteMessage(websocket.PingMessage,[]byte{});err!=nil{
				return
			}

		}
	}


}
func WsHander(hub *Hub,w http.ResponseWriter,r *http.Request){
	conn,err := upgrader.Upgrade(w,r,nil)
	if err!=nil{
		log.Fatal(err)
		return
	}
	client := &Client{conn:conn,message:make(chan []byte,256),hub:hub}
	client.hub.register<-client
	go client.read()
	client.write()



}