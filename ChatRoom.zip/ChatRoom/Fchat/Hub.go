package main

type Hub struct {
	clients map[*Client] bool
	broadcast chan []byte
	register chan *Client
	unregister chan *Client
}

func NewHub() *Hub {
	return &Hub{
		clients:make(map[*Client]bool),
		broadcast:make(chan []byte,256),
		register:make(chan *Client),
		unregister:make(chan *Client),
	}

}
func (hub *Hub)run()  {
	for  {
		select {
		case client:=<-hub.register:
			hub.clients[client]=true
		case client:=<-hub.unregister:
			if _,ok:=hub.clients[client];ok{
				close(client.message)
				delete(hub.clients,client)

			}
		case message:=<-hub.broadcast:
			for i,_:=range hub.clients{
				//可能正在广播的时候，client突然退出
				//这样,i.message=<-message这个过程就会被阻塞！！！
				select {
				case i.message<- message:
					default:
					close(i.message)
					delete(hub.clients,i)
				}

			}

		}

	}

}
